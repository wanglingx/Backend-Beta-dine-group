module.exports = {
    search_data : {
        res_name: '',
        food_name: '',
        type_name: ''
    },
    filterSearch: {
        religion_id :'',
        religion_name: '',
        type_id: '',
        type_name: ''
    }
}